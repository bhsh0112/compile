package dataStructure;

public class NNode extends ASTNode {
    public NNode(String name) {
        super("<" + name + ">");
    }
}
