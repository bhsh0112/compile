removed";
                    // //如果新定义的量不是常量，且原量（上层）是常量，则删除常量表中的对应内容
                    // if(element.kind.equals("Const")&&!isConst){
                    //     for(Element constElement:constSymbolTable){
                    //         if(constElement.name.equals(name)){
                    //             constElement.name="removed";
                    //         } 
                    //     }
                        
                    // }
                    // tmpNode.que.removeQue(element);