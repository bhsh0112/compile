if(element.type.equals("numofparams")&&element.kind.equals("Func")){
                continue;
            }