
import java.io.IOException;

import dataStructure.ASTNode.ASTNode;
import dataStructure.STT.STTNode;
import dataStructure.STT.STTQue.Element;
import lex.lexer;
import parser.parser;
import symbol.symbol;


public class Compiler {
    public static String inputFile = "testfile.txt";
    public static String outputFile = "symbol.txt";
    public static String errorFile = "error.txt";
    public static String[] totleTokens;
    public static ASTNode ASTRoot;
    public static STTNode STTRoot;

    public static void main(String[] args) throws IOException {
        totleTokens=lexer.main(inputFile,outputFile,errorFile);
        ASTRoot=parser.main(totleTokens,errorFile);
        STTRoot=symbol.main(ASTRoot,errorFile);
        STTPreorder(STTRoot);
    }
    private static void STTPreorder(STTNode parent){
        
        for(Element element:parent.que.que){
            if((!element.type.equals("numofparams"))&&(!element.type.equals("return"))) symbol.writeFile(outputFile,element.level+" "+element.name+" "+element.type+"\n");
        }
        for(STTNode child:parent.children){
            STTPreorder(child);
        }
    }
}
