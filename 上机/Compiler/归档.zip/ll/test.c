

int main()
{
    int i=0;
    int arr[15];
    arr[2]=i;
    return 0;
}
