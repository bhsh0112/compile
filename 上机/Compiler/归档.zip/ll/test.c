
int a=1;
int b=1;
int main() {
    if((!(a+b))&&(!(a-b))) {
        printf("success");
    }
    return 0;
}