
const int MAX_SIZE = 10;
int global_var;
char str[10]="3\'";
int main(){
    printf("%c\n",str[1]);
    return 0;
}