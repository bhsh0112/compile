#include <stdio.h>
int getint(void);
int getchar(void);

int main(){
    int d=1,a=1;
    int i=0;
    for(;i<d;i=i+1){
        break;
    }
    for(i=0;;i=i+1){
        break;
    }
    for(i=0;i<d;){
        break;
    }
    for(;;i=i+1){
        break;
    }
    for(;i<d;){
        break;
    }
    for(i=0;;){
        break;
    }
    for(;;){
        break;
    }
    if(!0){

    }else
    {
        
    }
    
    if(d>=a){

    };
    if(d<=a);
    if(d==a);
    if(d>a);
    if(d<a);
    if(d!=a);
    
    

    if(0&&d!=a){
        
    }
    if(1||a>0){
        //printf("pass\n");
    }
    if(!d==a||a>0&&1==1&&(d+1)%2/2){
        //printf("enter\n");
    }
    return 0;
}