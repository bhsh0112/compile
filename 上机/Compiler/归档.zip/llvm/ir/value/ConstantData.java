package llvm.ir.value;

public class ConstantData extends Constant{
    
}
