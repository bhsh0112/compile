package llvm.ir.value;

public class LocalArray extends Value{
    
}
