package dataStructure.ASTNode;

public class NNode extends ASTNode {
    public NNode(String name) {
        super("<" + name + ">");
    }
}
