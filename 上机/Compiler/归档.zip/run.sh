javac *.java && javac llvm/*.java && javac llvm/ir/*.java && javac llvm/ir/value/*.java && javac llvm/ir/value/inst/*.java && javac llvm/ir/value/Type/*.java
java Compiler