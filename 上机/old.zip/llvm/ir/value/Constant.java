package llvm.ir.value;

public class Constant extends Value{
    private int value;

    public void Value(int value){
        this.value=value;
    }
}
