package llvm.ir.value;

public class LOrExp {
    
}
