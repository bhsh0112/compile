package llvm.ir;

import java.util.ArrayList;
import java.util.List;

import llvm.ir.value.*;

public class LlvmContext {
    // private List<FunctionType> functionTypes;
    // private List<PointerType> pointerTypes;

    // private List<ValuePtr> values;
    // private List<UsePtr> uses;
};